<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCQkbC9-M9m8y8NPRm6agTbTZiLvbtcnZo&callback=initMap"
type="text/javascript"></script> -->
<?php /**PATH C:\xampp\htdocs\categoryApp\resources\views/layouts/script.blade.php ENDPATH**/ ?>