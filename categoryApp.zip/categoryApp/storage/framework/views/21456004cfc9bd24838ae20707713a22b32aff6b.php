

<?php $__env->startSection('title'); ?>
  <title>ระบบจัดการข้อมูลหมวดหมู่สินค้า</title>
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"> -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" />
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link href="/css/treeview.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenthome'); ?>

  <!-- Main content -->
  <section class="content">

    <div class="container">
  		<div class="panel panel-primary">
  			<div class="panel-heading">Manage Category TreeView</div>
  	  		<div class="panel-body">
  	  			<div class="row">
  	  				<div class="col-md-6">
  	  					<h3>Category List</h3>
  				        <ul id="tree1">
  				            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  				                <li>
  				                    <?php echo e($category->title); ?>

  				                    <?php if(count($category->childs)): ?>
  				                        <?php echo $__env->make('manageChild',['childs' => $category->childs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  				                    <?php endif; ?>
  				                </li>
  				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  				        </ul>
  	  				</div>
  	  				<div class="col-md-6">
  	  					<h3>Add New Category</h3>


  				  			<?php echo Form::open(['route'=>'add.category']); ?>



  				  				<?php if($message = Session::get('success')): ?>
  									<div class="alert alert-success alert-block">
  										<button type="button" class="close" data-dismiss="alert">×</button>
  									        <strong><?php echo e($message); ?></strong>
  									</div>
  								<?php endif; ?>


  				  				<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
  									<?php echo Form::label('Title:'); ?>

  									<?php echo Form::text('title', old('title'), ['class'=>'form-control', 'placeholder'=>'Enter Title']); ?>

  									<span class="text-danger"><?php echo e($errors->first('title')); ?></span>
  								</div>


  								<div class="form-group <?php echo e($errors->has('parent_id') ? 'has-error' : ''); ?>">
  									<?php echo Form::label('Category:'); ?>

  									<?php echo Form::select('parent_id',$allCategories, old('parent_id'), ['class'=>'form-control', 'placeholder'=>'Select Category']); ?>

  									<span class="text-danger"><?php echo e($errors->first('parent_id')); ?></span>
  								</div>


  								<div class="form-group">
  									<button class="btn btn-success">Add New</button>
  								</div>


  				  			<?php echo Form::close(); ?>



  	  				</div>
  	  			</div>


  	  		</div>
          </div>
      </div>
      <script src="/js/treeview.js"></script>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\categoryApp\resources\views/categoryTreeview.blade.php ENDPATH**/ ?>