<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class categories extends Model
{
    use HasFactory;

    public $table ='categories';
    public $primaryKey = 'id';
    public $fillable = ['title','parent_id'];

    public function childs() {
        return $this->hasMany('App\Models\categories','parent_id','id') ;
    }

    public function parent()
    {
        return $this->belongsTo('App\Models\categories', 'parent_id');
    }

    protected static function boot() {
      parent::boot();
      static::deleting( function ($category) {
        $category->childs->each(function($cat){
          $cat->delete();
        });
      });
    }

}
