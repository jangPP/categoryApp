<ul>
<?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li>
	    <?php echo e($child->title); ?>

			<a href="javascript:void(0)" onclick="edit(<?php echo e($child->id); ?>)" data-toggle="modal" data-target="#practice_modal">Edit</a>
			<a href="javascript:void(0)" onclick="deletes(<?php echo e($child->id); ?>)">Delete</a>
	<?php if(count($child->childs)): ?>
            <?php echo $__env->make('manageChild',['childs' => $child->childs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\xampp\htdocs\categoryApp\resources\views/manageChild.blade.php ENDPATH**/ ?>