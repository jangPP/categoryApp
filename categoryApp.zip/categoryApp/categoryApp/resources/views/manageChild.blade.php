<ul>
@foreach($childs as $child)
	<li>
	    {{ $child->title }}
			<a href="javascript:void(0)" onclick="edit({{ $child->id }})" data-toggle="modal" data-target="#practice_modal">Edit</a>
			<a href="javascript:void(0)" onclick="deletes({{ $child->id }})">Delete</a>
	@if(count($child->childs))
            @include('manageChild',['childs' => $child->childs])
        @endif
	</li>
@endforeach
</ul>
