@extends('layouts.main')

@section('title')
  <title>ระบบจัดการข้อมูลหมวดหมู่สินค้า</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" />
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link href="./css/treeview.css" rel="stylesheet">
@endsection

@section('contenthome')

  <!-- Main content -->
  <section class="content">

    <div class="container">
  		<div class="panel panel-primary">
  			<div class="panel-heading">จัดการข้อมูลสินค้า</div>
  	  		<div class="panel-body">
  	  			<div class="row">
  	  				<div class="col-md-6">
  	  					<h3>หมวดหมู่สินค้า</h3>
  				        <ul id="tree1">
  				            @foreach($categories as $category)
  				                <li>
  				                    {{ $category->title }}
                              <a href="javascript:void(0)" onclick="edit({{ $category->id }})" data-toggle="modal" data-target="#practice_modal">Edit</a>
                              <a href="javascript:void(0)" onclick="deletes({{ $category->id }})">Delete</a>
                              @if(count($category->childs))
  				                        @include('manageChild',['childs' => $category->childs])
  				                    @endif
  				                </li>
  				            @endforeach
  				        </ul>
  	  				</div>
  	  				<div class="col-md-6">
  	  					<h3>เพิ่มข้อมูลหมวดหมู่สินค้า</h3>

  				  			{!! Form::open(['route'=>'add-category'] ) !!}

  				  				@if ($message = Session::get('success'))
  									<div class="alert alert-success alert-block">
  										<button type="button" class="close" data-dismiss="alert">×</button>
  									        <strong>{{ $message }}</strong>
  									</div>
  								@endif

  				  				<div class="form-group {{ $errors->has('title') ? 'has-error' : '' }}">
  									{!! Form::label('ชื่อ:') !!}
  									{!! Form::text('title', old('title'), ['class'=>'form-control', 'placeholder'=>'เพิ่มชื่อหมวดหมู่ใหญ่, หมวดหมู่ย่อย, สินค้า ']) !!}
  									<span class="text-danger">{{ $errors->first('title') }}</span>
  								</div>

  								<div class="form-group {{ $errors->has('parent_id') ? 'has-error' : '' }}">
  									{!! Form::label('หมวดหมู่สินค้า:') !!}
  									{!! Form::select('parent_id',$allCategories, old('parent_id'), ['class'=>'form-control form-control-lg', 'placeholder'=>'เลือกหมวดหมู่สินค้า']) !!}
  									<span class="text-danger">{{ $errors->first('parent_id') }}</span>
  								</div>

  								<div class="form-group">
  									<button class="btn btn-success">เพิ่มข้อมูล</button>
  								</div>

  				  			{!! Form::close() !!}

  	  				</div>
  	  			</div>


  	  		</div>
          </div>
      </div>

      <!-- Modal_update -->
      <div class="modal fade" id="practice_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <form id="companydata">
            @csrf
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูล</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" id="id" name="id" />
              <input type="text" name="title" id="title" class="form-control" />
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
              <button type="button" class="btn btn-primary" id="submit" >แก้ไข</button>
            </div>
          </div>
          </form>
        </div>
      </div>

<script src="./js/treeview.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<script>
$.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});

function edit(id){
  // console.log(id);
  $.get('edit/'+id, function(data) {
       $('#id').val(data.id);
       $('#title').val(data.title);
       $('#practice_modal').modal('toggle');
   })
}

$('#submit').click(function() {
    var title = $('#title').val();
    var id = $("input[name=id]").val();
    var _token = $('input[name="_token"]').val();
    // console.log(id);
    // console.log(title);

    $.ajax({
       url: "{{ route('update') }}",
        method: "GET",
        data: {
            id: id,
            title: title,
            _token : _token
        },
        success: function(result) {
            window.location.reload(true);
        }
    });
});

</script>
<script>
$.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});

function deletes(id){
  // console.log(id);
  if(confirm("delete Record?")){
    $.ajax(
    {
        url: 'delete_categories/',
        method: "GET",
        type: 'DELETE',
        data: {
          id: id,
        },
        success: function (response){
            // console.log("it Works");
            window.location.reload(true);
        }
    });
  }

}
</script>
</section>

@endsection
