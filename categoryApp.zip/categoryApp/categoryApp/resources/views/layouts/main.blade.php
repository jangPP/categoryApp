<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  @yield('title')
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<style>
body.en{
font-size: 16px;
}
body.th {
font-size: 16px;
}
</style>

<body class="hold-transition skin-blue sidebar-mini {!! app()->getLocale(); !!}">
<div class="wrapper">
<header class="main-header">

  @include('layouts.top')

  </header>
  @include('layouts.left')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content">

    @yield('contenthome')

    </section>
    <!-- /.content -->
  </div>

  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

@include('layouts.script')
@yield('javascript')
</body>
</html>
