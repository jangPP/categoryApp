<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\categories;
use Illuminate\Support\Facades\Auth;

class CategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function manageCategory()
     {
       if(Auth::check()){
         $categories = categories::where('parent_id', '=', 0)->get();
         $allCategories = categories::pluck('title','id')->all();
         return view('dashboard',compact('categories','allCategories'));
       }

       return redirect("login")->withSuccess('You are not allowed to access');
     }

    public function addCategory(Request $request)
    {
        $this->validate($request, [
        		'title' => 'required',
        	]);
        $input = $request->all();
        $input['parent_id'] = empty($input['parent_id']) ? 0 : $input['parent_id'];

        categories::create($input);
        return back()->with('success', 'New Category added successfully.');
    }

    public function edit(Request $request, $id)
    {
      $category = categories::find($id);
      return response()->json(['id' => $category->id, 'title' => $category->title]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
      $category = categories::find($request->id);
      $category->title = $request->title;
      $category->save();

      // return response()->json($data2);
      return response()->json(['success'=>'Got Simple Ajax Request.']);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function destroy(Request $request) {
       categories::destroy($request->input('id'));
       return json_encode(array('statusCode'=>200));
    }

}
