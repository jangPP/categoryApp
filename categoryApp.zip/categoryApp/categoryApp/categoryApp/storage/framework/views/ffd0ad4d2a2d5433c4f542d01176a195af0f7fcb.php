
<?php /**PATH C:\xampp\htdocs\categoryApp\resources\views/layouts/left.blade.php ENDPATH**/ ?>