<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <?php echo $__env->yieldContent('title'); ?>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<style>
body.en{
font-size: 16px;
}
body.th {
font-size: 16px;
}
</style>

<body class="hold-transition skin-blue sidebar-mini <?php echo app()->getLocale(); ?>">
<div class="wrapper">
<header class="main-header">

  <?php echo $__env->make('layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </header>
  <?php echo $__env->make('layouts.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content">

    <?php echo $__env->yieldContent('contenthome'); ?>

    </section>
    <!-- /.content -->
  </div>

  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\categoryApp\resources\views/layouts/main.blade.php ENDPATH**/ ?>