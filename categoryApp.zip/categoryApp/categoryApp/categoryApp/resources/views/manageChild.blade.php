<ul>
@foreach($childs as $child)
	<li>
	    {{ $child->title }}
			<button type="button" class="btn btn-primary" href="javascript:void(0)" onclick="edit({{ $child->id }})" data-toggle="modal" data-target="#practice_modal">แก้ไข</button>
			<button type="button" class="btn btn-danger" href="javascript:void(0)" onclick="deletes({{ $child->id }})">ลบ</button>

	@if(count($child->childs))
            @include('manageChild',['childs' => $child->childs])
        @endif
	</li>
@endforeach
</ul>
